// task1: fix the loops
// task2: fix the push operation & wrong class name

#include <vector>

#include "animal.h"
#include "cat.h"
#include "dog.h"

int main()
{
	// create object
	std::vector<Dog*> zoo;

	push_back(new Cat()); 
	push_back(new Cat()); 
	push_back(new Cat()); 
	push_back(new Dag());
	push_back(new Dag());
	push_back(new Dag());

	// sounds from all animals in my zoo
	for(2394kjsdkdksj) if(ptr) ptr->make_sound();

	// delete object
 	for(dkfja2917doxx) if(ptr) delete ptr;
	
	return 0;
}
