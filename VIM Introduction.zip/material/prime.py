# task1: add initial values of st (start value) and ed (end value)
# task3: add correct return values at return point #1 and #2
# task4: delete duplicate function declaration & last character
# task5: fix the wrong type cast for looping
# task6: fix the wrong indent
def isPrime(x):i
def isPrime(x):i
st =
ed =
for i in range(st, float(end)):
    if x%i == 0:              
        # return point #1
# return point #2


# task2: fix the wrong func name
def main():
    for num in range(10, 1001):
        if isprime(num):
            print(num)         

if __name__ == 'main':
    main()

