#pragma once 
#include <iostream>

class Animal {
	public:
		virtual void make_sound() const = 0;
};
