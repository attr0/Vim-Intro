#pragma once 
#include <iostream>

class Animal {
	public:
		void make_sound() const = 0;
};
